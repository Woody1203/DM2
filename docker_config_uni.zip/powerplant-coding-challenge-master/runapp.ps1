$env:FLASK_APP = "powerplant"
$env:FLASK_ENV = "development"
flask run --host 127.0.0.1 --port 8888
