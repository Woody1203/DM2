class Config:
    DEBUG = False
    TESTING = False

class DevelopmentConfig:
    DEBUG = True
    TESTING = False
